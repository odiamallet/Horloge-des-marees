# Marée & Horloge — app Android + widget

## Ce que contient ce projet

- **L'app complète** : ton HTML/JS d'origine, tel quel, chargé dans une WebView
  (fichier `app/src/main/assets/index.html`). Le stockage `window.storage` des
  artefacts Claude a été remplacé par une implémentation `localStorage` +
  un pont vers l'app Android, pour que ça marche en dehors de claude.ai.
- **Le widget natif** (`ClockWidgetProvider.kt`) : un vrai widget Android,
  **rond**, posable sur l'écran d'accueil, qui reprend l'illustration du
  cadran de l'app (fond aquarelle) et affiche :
  - le nom du site en haut du cadran ;
  - les deux aiguilles (phase de marée en jaune, niveau d'eau en rouge),
    aux mêmes proportions que dans l'app ;
  - l'heure en bas du cadran (HH:mm) ;
  - le tout redessiné au maximum toutes les 30 minutes.

**Limite technique importante** : Android n'autorise pas un widget à se
redessiner en continu comme une page web (pas de trotteuse fluide). Le
`updatePeriodMillis` minimum imposé par le système est de 30 minutes. Comme
la marée évolue lentement (cycle ~6h), ce n'est pas gênant en pratique. Le
widget se remet aussi à jour automatiquement dès que tu changes la clé API
ou le site dans l'app.

## Installation d'Android Studio

1. Télécharge-le ici : https://developer.android.com/studio (gratuit)
2. Installe-le et laisse-le télécharger le SDK Android par défaut lors du
   premier lancement (assistant "Setup Wizard").

## Ouvrir le projet

1. Dézippe le fichier que je t'ai fourni.
2. Dans Android Studio : **File → Open**, puis sélectionne le dossier
   `MareeHorloge` (celui qui contient `settings.gradle`).
3. Laisse Gradle synchroniser (ça peut prendre plusieurs minutes la première
   fois, connexion internet nécessaire pour télécharger les dépendances).

## Lancer l'app sur ton téléphone

1. Sur le téléphone : **Paramètres → À propos du téléphone**, tape 7 fois
   sur "Numéro de build" pour activer le mode développeur.
2. **Paramètres → Options pour les développeurs**, active le
   **débogage USB**.
3. Branche le téléphone en USB, autorise le débogage si une popup apparaît.
4. Dans Android Studio, sélectionne ton téléphone dans la liste déroulante
   en haut, puis clique sur **Run ▶** (ou Shift+F10).
5. L'app s'installe et s'ouvre automatiquement sur le téléphone.

## Configurer

1. Dans l'app, ouvre **Clé API** (en bas) et colle ta clé api-maree.fr.
2. Ajoute ton site de marée habituel (comme avant).
3. Le widget utilise automatiquement le **premier site enregistré** dans
   la liste.

## Ajouter le widget à l'écran d'accueil

1. Appui long sur un espace vide de l'écran d'accueil.
2. **Widgets**.
3. Cherche **"Marée & Horloge"**.
4. Glisse le widget **"Horloge des marées"** sur l'écran.

## Pistes d'amélioration si tu veux aller plus loin

- Ajouter le **coefficient de marée** sur le widget (actuellement calculé
  seulement dans l'app web, pas repris côté widget natif).
- Permettre de choisir, dans l'app, **quel site** afficher dans le widget
  (actuellement toujours le premier de la liste).
- Ajouter une **icône propre** (actuellement une icône vectorielle simple,
  personnalisable via un clic droit sur `res` → **New → Image Asset** dans
  Android Studio).
- Passer d'un simple `Thread`/coroutine à `WorkManager` pour un
  rafraîchissement plus robuste en arrière-plan.

Pour toutes ces suites, tu peux directement demander à Claude Code (ou à
moi dans une prochaine conversation) de reprendre ce projet.
