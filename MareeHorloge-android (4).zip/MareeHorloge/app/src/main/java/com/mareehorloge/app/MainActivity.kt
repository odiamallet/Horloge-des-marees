package com.mareehorloge.app

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(WebAppBridge(this), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    /**
     * Pont appelé depuis le JavaScript de l'app (voir le shim window.storage
     * dans assets/index.html) à chaque fois que la clé API ou la liste des
     * sites enregistrés est sauvegardée. On duplique la valeur dans les
     * SharedPreferences Android, seul endroit que le widget (processus /
     * composant séparé) peut lire.
     */
    class WebAppBridge(private val context: Context) {
        @JavascriptInterface
        fun saveToPrefs(key: String, value: String) {
            val prefs = context.getSharedPreferences("maree_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString(key, value).apply()

            val ids = AppWidgetManager.getInstance(context)
                .getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}
