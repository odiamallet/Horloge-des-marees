package com.mareehorloge.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Widget d'écran d'accueil "horloge des marées".
 *
 * Tout le rendu (fond du cadran découpé en cercle, aiguilles, nom du site,
 * heure) est composé dans un seul bitmap carré à fond transparent en dehors
 * du cercle — c'est ce qui donne l'apparence d'un widget rond posé sur
 * l'écran d'accueil, sans carré visible autour.
 *
 * Limite importante d'Android : un widget ne peut pas se redessiner en
 * continu comme le ferait une page web (pas de trotteuse fluide). L'heure
 * et les aiguilles sont recalculées et redessinées au maximum toutes les 30
 * minutes (android:updatePeriodMillis, minimum imposé par le système), ou
 * dès que l'app est ouverte / la config change (voir MainActivity.kt).
 */
class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
        val prefs: SharedPreferences = context.getSharedPreferences("maree_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("apimaree-key", null)
        val sitesJson = prefs.getString("apimaree-saved-sites", null)

        val views = RemoteViews(context.packageName, R.layout.widget_clock)
        val density = context.resources.displayMetrics.density

        if (apiKey.isNullOrBlank() || sitesJson.isNullOrBlank()) {
            views.setImageViewBitmap(
                R.id.widget_dial,
                drawEmptyDial(context, density, "Ouvre l'app pour\najouter ta clé API\net ton site")
            )
            appWidgetManager.updateAppWidget(widgetId, views)
            return
        }

        val site = try {
            val arr = JSONArray(sitesJson)
            if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                Pair(obj.getString("id"), obj.optString("name", ""))
            } else null
        } catch (e: Exception) {
            null
        }

        if (site == null) {
            views.setImageViewBitmap(
                R.id.widget_dial,
                drawEmptyDial(context, density, "Aucun site\nenregistré")
            )
            appWidgetManager.updateAppWidget(widgetId, views)
            return
        }
        val (siteId, siteName) = site

        CoroutineScope(Dispatchers.IO).launch {
            val bitmap = try {
                val events = fetchTideEvents(siteId, apiKey)
                val calibration = try {
                    fetchCalibration(siteId, apiKey)
                } catch (e: Exception) {
                    null // pas grave : le coefficient restera juste masqué
                }
                drawDial(context, density, events, siteName, calibration)
            } catch (e: Exception) {
                drawEmptyDial(context, density, "Erreur réseau")
            }
            views.setImageViewBitmap(R.id.widget_dial, bitmap)
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }

    /**
     * Fenêtre de calibration pour le coefficient (-14j à +15j, pas de 30 min),
     * comme fetchCoefficientCalibration() dans l'app web : calcule
     * l'amplitude min/max observée entre marées consécutives sur ~1 mois,
     * qui sert d'échelle pour convertir une amplitude en coefficient 20-120.
     */
    private fun fetchCalibration(siteId: String, apiKey: String): Pair<Double, Double>? {
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val from = dayFmt.format(Date(System.currentTimeMillis() - 14L * 24 * 3600 * 1000))
        val to = dayFmt.format(Date(System.currentTimeMillis() + 15L * 24 * 3600 * 1000))

        val url = URL(
            "https://api-maree.fr/water-levels?site=$siteId&from=${from}T00:00" +
                "&to=${to}T00:00&step=30&tz=Europe/Paris&key=$apiKey"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val body = conn.inputStream.bufferedReader().readText()
        val json = JSONObject(body)
        val data = json.getJSONArray("data")

        val series = mutableListOf<Double>()
        for (i in 0 until data.length()) {
            series.add(data.getJSONObject(i).getDouble("height"))
        }

        // extrema locaux (mêmes conditions que computeExtrema côté app)
        val extrema = mutableListOf<Double>()
        for (i in 1 until series.size - 1) {
            val prev = series[i - 1]; val cur = series[i]; val next = series[i + 1]
            if ((cur >= prev && cur >= next && cur > prev) || (cur <= prev && cur <= next && cur < prev)) {
                extrema.add(cur)
            }
        }
        if (extrema.size < 2) return null

        val amplitudes = (0 until extrema.size - 1).map { Math.abs(extrema[it + 1] - extrema[it]) }
        val min = amplitudes.minOrNull() ?: return null
        val max = amplitudes.maxOrNull() ?: return null
        return Pair(min, max)
    }

    private data class TideEvent(val time: Date, val height: Double, val isHigh: Boolean)

    private fun fetchTideEvents(siteId: String, apiKey: String): List<TideEvent> {
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = dayFmt.format(Date())
        val tomorrow = dayFmt.format(Date(System.currentTimeMillis() + 24 * 3600 * 1000))

        val url = URL(
            "https://api-maree.fr/water-levels?site=$siteId&from=${today}T00:00" +
                "&to=${tomorrow}T00:00&step=10&tz=Europe/Paris&key=$apiKey"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val body = conn.inputStream.bufferedReader().readText()
        val json = JSONObject(body)
        val data = json.getJSONArray("data")

        val series = mutableListOf<Pair<Date, Double>>()
        for (i in 0 until data.length()) {
            val p = data.getJSONObject(i)
            series.add(Pair(parseFlexibleDate(p.getString("time")), p.getDouble("height")))
        }

        val events = mutableListOf<TideEvent>()
        for (i in 1 until series.size - 1) {
            val prev = series[i - 1].second
            val cur = series[i].second
            val next = series[i + 1].second
            if (cur >= prev && cur >= next && cur > prev) {
                events.add(TideEvent(series[i].first, cur, true))
            } else if (cur <= prev && cur <= next && cur < prev) {
                events.add(TideEvent(series[i].first, cur, false))
            }
        }
        return events
    }

    private fun parseFlexibleDate(s: String): Date {
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm"
        )
        for (p in patterns) {
            try {
                return SimpleDateFormat(p, Locale.US).parse(s) ?: continue
            } catch (e: Exception) {
                // essaie le format suivant
            }
        }
        return Date()
    }

    // ================= dessin =================

    private val WIDGET_SIZE_DP = 220

    /** Charge dial_bg.webp (le fond du cadran de l'app) et le met à l'échelle en carré. */
    private fun loadDialBackground(context: Context, size: Int): Bitmap {
        val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val src = BitmapFactory.decodeResource(context.resources, R.drawable.dial_bg, opts)
        return Bitmap.createScaledBitmap(src, size, size, true)
    }

    private fun drawDial(context: Context, density: Float, events: List<TideEvent>, siteName: String, calibration: Pair<Double, Double>?): Bitmap {
        val size = (WIDGET_SIZE_DP * density).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = size / 2f
        val cy = size / 2f
        val radius = size / 2f

        // découpe circulaire : tout ce qui est dessiné ensuite reste dans le cercle,
        // le reste du bitmap est transparent -> effet "widget rond"
        val clip = Path().apply { addCircle(cx, cy, radius, Path.Direction.CW) }
        canvas.clipPath(clip)

        canvas.drawBitmap(loadDialBackground(context, size), 0f, 0f, null)

        val now = Date()
        val prevEvent = events.filter { !it.time.after(now) }.maxByOrNull { it.time.time }
        val nextEvent = events.filter { it.time.after(now) }.minByOrNull { it.time.time }

        if (prevEvent != null && nextEvent != null) {
            val base = if (prevEvent.isHigh) 0.0 else 180.0
            val total = (nextEvent.time.time - prevEvent.time.time).toDouble().coerceAtLeast(1.0)
            val elapsed = (now.time - prevEvent.time.time).toDouble()
            val frac = (elapsed / total).coerceIn(0.0, 1.0)

            // proportions identiques au cadran SVG de l'app (viewBox 800x800,
            // centre 400,400) : aiguille de phase (jaune) = 65% du rayon,
            // aiguille de niveau (rouge) = 40% du rayon
            val phaseAngle = base + frac * 180.0
            drawHand(canvas, cx, cy, radius * 0.65f, phaseAngle, Color.parseColor("#F4C542"), 5.5f * density, Color.parseColor("#FFFDF7"))

            val h = prevEvent.height + (nextEvent.height - prevEvent.height) * frac
            val meterAngle = ((h % 12) + 12) % 12 * 30.0
            drawHand(canvas, cx, cy, radius * 0.40f, meterAngle, Color.parseColor("#FF5A3C"), 6.5f * density, Color.parseColor("#FFFDF7"))
        }

        // moyeu central
        canvas.drawCircle(cx, cy, 5.5f * density, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#C9A473")
        })
        canvas.drawCircle(cx, cy, 5.5f * density, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#123241")
            style = Paint.Style.STROKE
            strokeWidth = 1.2f * density
        })

        // heure de la prochaine marée haute et de la prochaine marée basse
        // (toujours dans le futur, comme demandé — indépendant du sens de la
        // marée actuelle). Texte clair + halo sombre : bon contraste sur ce
        // fond bleu nuit, contrairement au texte sombre utilisé au tout début.
        val timeFmt = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val textColor = Color.parseColor("#FFFDF7")
        val haloColor = Color.parseColor("#0B2530")
        val nextHigh = events.filter { it.time.after(now) && it.isHigh }.minByOrNull { it.time.time }
        val nextLow = events.filter { it.time.after(now) && !it.isHigh }.minByOrNull { it.time.time }

        drawCenteredText(
            canvas, nextHigh?.let { timeFmt.format(it.time) } ?: "--:--",
            cx, cy - radius * 0.50f, 14f * density, textColor, haloColor, bold = true
        )
        drawCenteredText(
            canvas, nextLow?.let { timeFmt.format(it.time) } ?: "--:--",
            cx, cy + radius * 0.55f, 14f * density, textColor, haloColor, bold = true
        )

        // coefficient de marée (juste au-dessus du moyeu), même calcul que
        // dans l'app : amplitude entre la marée haute de référence et sa
        // voisine, ramenée sur l'échelle 20-120 via l'amplitude min/max
        // observée sur ~1 mois (calibration). Couleur laiton, comme dans
        // l'app (dial-coef).
        val coefficient = computeCoefficient(events, calibration, now)
        if (coefficient != null) {
            drawCenteredText(
                canvas, coefficient.toString(),
                cx, cy - radius * 0.16f, 15f * density, Color.parseColor("#E9CE8E"), Color.parseColor("#0B2530"), bold = true
            )
        }

        return bmp
    }

    /**
     * Reproduit coefficientFor()/attachCoefficients()/updateDialCoefficient()
     * de l'app web : le coefficient est une estimation basée sur l'amplitude
     * de la marée de référence (la prochaine haute, ou la dernière si aucune
     * à venir) comparée à sa voisine, ramenée sur l'échelle 20-120 via le
     * marnage min/max observé sur la fenêtre de calibration.
     */
    private fun computeCoefficient(events: List<TideEvent>, calibration: Pair<Double, Double>?, now: Date): Int? {
        if (calibration == null) return null
        val (calibMin, calibMax) = calibration
        if (calibMax <= calibMin) return null

        val highs = events.filter { it.isHigh }
        val candidate = highs.firstOrNull { it.time.after(now) } ?: highs.lastOrNull() ?: return null
        val idx = events.indexOf(candidate)
        val neighbor = events.getOrNull(idx - 1) ?: events.getOrNull(idx + 1) ?: return null

        val amplitude = Math.abs(candidate.height - neighbor.height)
        val raw = 20.0 + 100.0 * (amplitude - calibMin) / (calibMax - calibMin)
        return raw.coerceIn(20.0, 120.0).toInt()
    }

    private fun drawHand(
        canvas: Canvas, cx: Float, cy: Float, length: Float, angleDeg: Double,
        color: Int, width: Float, haloColor: Int
    ) {
        val rad = Math.toRadians(angleDeg - 90.0)
        val ex = cx + (length * Math.cos(rad)).toFloat()
        val ey = cy + (length * Math.sin(rad)).toFloat()
        // halo clair derrière l'aiguille, comme dans l'app, pour la lisibilité sur l'image
        canvas.drawLine(cx, cy, ex, ey, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = haloColor
            strokeWidth = width + 3.5f
            strokeCap = Paint.Cap.ROUND
            alpha = 190
        })
        canvas.drawLine(cx, cy, ex, ey, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = width
            strokeCap = Paint.Cap.ROUND
        })
    }

    private fun drawCenteredText(canvas: Canvas, text: String, cx: Float, y: Float, textSize: Float, color: Int, haloColor: Int, bold: Boolean) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSize
            textAlign = Paint.Align.CENTER
            if (bold) isFakeBoldText = true
        }
        // halo de contraste (couleur opposée au texte) pour rester lisible
        // par-dessus l'illustration du cadran, quel que soit ce qu'il y a dessous
        val halo = Paint(paint).apply {
            this.color = haloColor
            style = Paint.Style.STROKE
            strokeWidth = 3.2f
        }
        canvas.drawText(text, cx, y, halo)
        canvas.drawText(text, cx, y, paint)
    }

    private fun drawEmptyDial(context: Context, density: Float, message: String): Bitmap {
        val size = (WIDGET_SIZE_DP * density).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = size / 2f
        val cy = size / 2f
        val radius = size / 2f

        val clip = Path().apply { addCircle(cx, cy, radius, Path.Direction.CW) }
        canvas.clipPath(clip)
        canvas.drawBitmap(loadDialBackground(context, size), 0f, 0f, Paint().apply { alpha = 235 })
        canvas.drawColor(Color.parseColor("#33F3ECDC"))

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#153241")
            textSize = 12.5f * density
            textAlign = Paint.Align.CENTER
        }
        message.split("\n").forEachIndexed { i, line ->
            canvas.drawText(line, cx, cy + (i * 16 * density) - 8 * density, textPaint)
        }
        return bmp
    }
}
