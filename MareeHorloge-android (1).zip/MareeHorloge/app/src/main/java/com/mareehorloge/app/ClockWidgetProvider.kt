package com.mareehorloge.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Widget d'écran d'accueil "horloge des marées".
 *
 * Limite importante d'Android : un widget ne peut pas se redessiner en
 * continu comme le ferait une page web (pas de trotteuse fluide). L'heure
 * affichée en bas utilise un <TextClock> natif qui, lui, se met à jour tout
 * seul en direct sans coût batterie. Les aiguilles de marée (qui bougent
 * lentement sur un cycle de ~6h) sont recalculées et redessinées au maximum
 * toutes les 30 minutes (android:updatePeriodMillis, minimum imposé par le
 * système), ou quand l'app est ouverte / la config change.
 */
class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
        val prefs: SharedPreferences = context.getSharedPreferences("maree_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("apimaree-key", null)
        val sitesJson = prefs.getString("apimaree-saved-sites", null)

        val views = RemoteViews(context.packageName, R.layout.widget_clock)

        if (apiKey.isNullOrBlank() || sitesJson.isNullOrBlank()) {
            views.setImageViewBitmap(
                R.id.widget_dial,
                drawEmptyDial(context.resources.displayMetrics.density, "Ouvre l'app pour ajouter\nta clé API et ton site")
            )
            appWidgetManager.updateAppWidget(widgetId, views)
            return
        }

        val siteId = try {
            val arr = JSONArray(sitesJson)
            if (arr.length() > 0) arr.getJSONObject(0).getString("id") else null
        } catch (e: Exception) {
            null
        }

        if (siteId == null) {
            views.setImageViewBitmap(
                R.id.widget_dial,
                drawEmptyDial(context.resources.displayMetrics.density, "Aucun site enregistré")
            )
            appWidgetManager.updateAppWidget(widgetId, views)
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            val bitmap = try {
                val events = fetchTideEvents(siteId, apiKey)
                drawDial(context.resources.displayMetrics.density, events)
            } catch (e: Exception) {
                drawEmptyDial(context.resources.displayMetrics.density, "Erreur réseau")
            }
            views.setImageViewBitmap(R.id.widget_dial, bitmap)
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }

    private data class TideEvent(val time: Date, val height: Double, val isHigh: Boolean)

    private fun fetchTideEvents(siteId: String, apiKey: String): List<TideEvent> {
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = dayFmt.format(Date())
        val tomorrow = dayFmt.format(Date(System.currentTimeMillis() + 24 * 3600 * 1000))

        val url = URL(
            "https://api-maree.fr/water-levels?site=$siteId&from=${today}T00:00" +
                "&to=${tomorrow}T00:00&step=10&tz=Europe/Paris&key=$apiKey"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val body = conn.inputStream.bufferedReader().readText()
        val json = JSONObject(body)
        val data = json.getJSONArray("data")

        val series = mutableListOf<Pair<Date, Double>>()
        for (i in 0 until data.length()) {
            val p = data.getJSONObject(i)
            series.add(Pair(parseFlexibleDate(p.getString("time")), p.getDouble("height")))
        }

        val events = mutableListOf<TideEvent>()
        for (i in 1 until series.size - 1) {
            val prev = series[i - 1].second
            val cur = series[i].second
            val next = series[i + 1].second
            if (cur >= prev && cur >= next && cur > prev) {
                events.add(TideEvent(series[i].first, cur, true))
            } else if (cur <= prev && cur <= next && cur < prev) {
                events.add(TideEvent(series[i].first, cur, false))
            }
        }
        return events
    }

    private fun parseFlexibleDate(s: String): Date {
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm"
        )
        for (p in patterns) {
            try {
                return SimpleDateFormat(p, Locale.US).parse(s) ?: continue
            } catch (e: Exception) {
                // essaie le format suivant
            }
        }
        return Date()
    }

    private fun drawDial(density: Float, events: List<TideEvent>): Bitmap {
        val size = (200 * density).toInt().coerceAtLeast(200)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = size / 2f
        val cy = size / 2f
        val radius = size / 2f - (10 * density)

        canvas.drawCircle(cx, cy, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F3ECDC")
        })
        canvas.drawCircle(cx, cy, radius, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#C9A473")
            style = Paint.Style.STROKE
            strokeWidth = 3 * density
        })

        val now = Date()
        val prevEvent = events.filter { !it.time.after(now) }.maxByOrNull { it.time.time }
        val nextEvent = events.filter { it.time.after(now) }.minByOrNull { it.time.time }

        if (prevEvent != null && nextEvent != null) {
            val base = if (prevEvent.isHigh) 0.0 else 180.0
            val total = (nextEvent.time.time - prevEvent.time.time).toDouble().coerceAtLeast(1.0)
            val elapsed = (now.time - prevEvent.time.time).toDouble()
            val frac = (elapsed / total).coerceIn(0.0, 1.0)
            val phaseAngle = base + frac * 180.0
            drawHand(canvas, cx, cy, radius * 0.6f, phaseAngle, Color.parseColor("#F4C542"), 6 * density)

            val h = prevEvent.height + (nextEvent.height - prevEvent.height) * frac
            val meterAngle = ((h % 12) + 12) % 12 * 30.0
            drawHand(canvas, cx, cy, radius * 0.85f, meterAngle, Color.parseColor("#FF5A3C"), 7 * density)
        }

        return bmp
    }

    private fun drawHand(canvas: Canvas, cx: Float, cy: Float, length: Float, angleDeg: Double, color: Int, width: Float) {
        val rad = Math.toRadians(angleDeg - 90.0)
        val ex = cx + (length * Math.cos(rad)).toFloat()
        val ey = cy + (length * Math.sin(rad)).toFloat()
        canvas.drawLine(cx, cy, ex, ey, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = width
            strokeCap = Paint.Cap.ROUND
        })
    }

    private fun drawEmptyDial(density: Float, message: String): Bitmap {
        val size = (200 * density).toInt().coerceAtLeast(200)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawCircle(size / 2f, size / 2f, size / 2f - (10 * density), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F3ECDC")
        })
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#153241")
            textSize = 13 * density
            textAlign = Paint.Align.CENTER
        }
        message.split("\n").forEachIndexed { i, line ->
            canvas.drawText(line, size / 2f, size / 2f + (i * 16 * density) - 8 * density, textPaint)
        }
        return bmp
    }
}
