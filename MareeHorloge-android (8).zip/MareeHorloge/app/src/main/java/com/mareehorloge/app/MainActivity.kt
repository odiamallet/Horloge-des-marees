package com.mareehorloge.app

import android.annotation.SuppressLint
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = ExternalLinksWebViewClient()
        webView.addJavascriptInterface(WebAppBridge(this), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")

        // s'assure que le rafraîchissement périodique du widget est bien
        // programmé même si onEnabled() du widget n'a pas pu tourner pour
        // une raison ou une autre (ex: mise à jour de l'app)
        WidgetRefreshWorker.schedule(this)

        // à chaque ouverture de l'app, on redemande aussi une mise à jour
        // immédiate du widget (utile si ses données étaient périmées)
        requestWidgetRefreshNow(this)
    }

    /**
     * Intercepte la navigation de la WebView : tout lien qui ne pointe pas
     * vers l'app elle-même (file:///android_asset/...) est ouvert dans le
     * navigateur par défaut du téléphone (Chrome, en général) via une
     * intent système, plutôt que de rester coincé dans la WebView où
     * cliquer dessus ne faisait rien.
     */
    private class ExternalLinksWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url
            if (url.scheme == "http" || url.scheme == "https") {
                view.context.startActivity(Intent(Intent.ACTION_VIEW, url))
                return true
            }
            return false
        }
    }

    private fun requestWidgetRefreshNow(context: Context) {
        val ids = AppWidgetManager.getInstance(context)
            .getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
        if (ids.isNotEmpty()) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }

    /**
     * Pont appelé depuis le JavaScript de l'app (voir le shim window.storage
     * dans assets/index.html) à chaque fois que la clé API ou la liste des
     * sites enregistrés est sauvegardée. On duplique la valeur dans les
     * SharedPreferences Android, seul endroit que le widget (processus /
     * composant séparé) peut lire.
     */
    class WebAppBridge(private val context: Context) {
        @JavascriptInterface
        fun saveToPrefs(key: String, value: String) {
            val prefs = context.getSharedPreferences("maree_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString(key, value).apply()

            val ids = AppWidgetManager.getInstance(context)
                .getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}
