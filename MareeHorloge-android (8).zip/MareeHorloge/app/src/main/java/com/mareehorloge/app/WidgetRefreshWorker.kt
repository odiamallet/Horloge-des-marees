package com.mareehorloge.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * android:updatePeriodMillis (utilisé par ClockWidgetProvider) est le
 * mécanisme standard pour rafraîchir un widget, mais il est notoirement peu
 * fiable sur certains téléphones (Samsung en particulier, avec sa gestion
 * batterie agressive qui peut retarder ou sauter des mises à jour, laissant
 * le widget bloqué avec de vieilles données). WorkManager est plus robuste
 * car il passe par plusieurs mécanismes système (JobScheduler/AlarmManager
 * selon la version d'Android) et survit mieux au Doze / à la mise en
 * veille de l'app.
 *
 * Ce Worker se contente de rediffuser une mise à jour vers tous les widgets
 * actuellement posés — c'est le même chemin de code que le rafraîchissement
 * automatique normal (ClockWidgetProvider.onUpdate).
 */
class WidgetRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val appWidgetManager = AppWidgetManager.getInstance(applicationContext)
        val ids = appWidgetManager.getAppWidgetIds(ComponentName(applicationContext, ClockWidgetProvider::class.java))
        if (ids.isEmpty()) return Result.success()

        val provider = ClockWidgetProvider()
        for (id in ids) {
            provider.refreshOne(applicationContext, appWidgetManager, id)
        }
        return Result.success()
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "maree_widget_refresh"

        /** À appeler quand au moins un widget est posé (onEnabled) ou à l'ouverture de l'app. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<WidgetRefreshWorker>(30, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /** À appeler quand le dernier widget est retiré (onDisabled). */
        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}
